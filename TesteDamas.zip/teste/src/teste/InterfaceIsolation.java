package teste;

import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.Rectangle;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class InterfaceIsolation extends JFrame {
	
	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;
	
	protected boolean emRede = false;
	protected String idJ1 = "";
	
	private JLabel vPosicao0000 = null;
	private JLabel vPosicao0001 = null;
	private JLabel vPosicao0002 = null;	
	private JLabel vPosicao0003 = null;
	private JLabel vPosicao0004 = null;
	private JLabel vPosicao0005 = null;
	private JLabel vPosicao0006 = null;
	private JLabel vPosicao0007 = null;
	private JLabel vPosicao0008 = null;
	private JLabel vPosicao0009 = null;
	private JLabel vPosicao0010 = null;
	private JLabel vPosicao0011 = null;
	private JLabel vPosicao0012 = null;
	
	protected JLabel mapaVPosicao[][] = new JLabel[17][13];

    private JMenuBar jMenuBar1 = null;
	
	private JMenu menuJogo = null;

	private JMenuItem jMenuItem1 = null;

	private JMenuItem jMenuItem2 = null;

	private JMenuItem jMenuItem3 = null;
	
	private JLabel vMensagem = null;
	
	public InterfaceIsolation() throws HeadlessException {
		super();
		initialize();
	}

	public InterfaceIsolation(GraphicsConfiguration arg0) {
		super(arg0);
		initialize();
	}

	public InterfaceIsolation(String arg0) throws HeadlessException {
		super(arg0);
		initialize();
	}

	public InterfaceIsolation(String arg0, GraphicsConfiguration arg1) {
		super(arg0, arg1);
		initialize();
	}
	
	private void initialize() {
		this.setSize(560, 630);
		this.setContentPane(getJContentPane());
	}
	
	public JPanel getJContentPane() {
		if(jContentPane==null) {
			
			int[][] ordem = {
	                {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0},
	                {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
	                {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
	                {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
	                {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	                {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	                {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	                {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
	                {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
	                {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
	                {0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0},
	                {0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0}
	        };
			
			Icon vazia =new ImageIcon(getClass().getResource("casaVazia.png"));

			jContentPane = new JPanel();
			for(int i = 0; i < 17; i++){
					for(int j = 0; j < 13; j++){
					JLabel v = new JLabel();
					v.setBounds(new Rectangle(j*27, i*27, 27, 27));
					if (ordem[i][j] == 1) {
						v.setIcon(vazia);
					} else {
						v.setIcon(null);
					}
					
									
	
					jContentPane.setLayout(null);
					jContentPane.add(v, null);
					mapaVPosicao[i][j] = v;
				}
			}
			/*
			vPosicao0000 = new JLabel();
			vPosicao0000.setBounds(new Rectangle(27, 27, 27, 27));
			vPosicao0000.setIcon(null);				

			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(vPosicao0000, null);
			
			mapaVPosicao[0][0] = vPosicao0000;
			
			vPosicao0001 = new JLabel();
			vPosicao0001.setBounds(new Rectangle(54, 27, 27, 27));
			vPosicao0001.setIcon(null);				

			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(vPosicao0001, null);
			
			mapaVPosicao[0][1] = vPosicao0001;
			//
			vPosicao0000 = new JLabel();
			vPosicao0000.setBounds(new Rectangle(27, 27, 27, 27));
			vPosicao0000.setIcon(null);				

			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(vPosicao0000, null);
			
			mapaVPosicao[0][0] = vPosicao0000;
*/
		}
		return jContentPane;
	}

}